#include<stdio.h>

// Program to print pattern_3 i.e left hald pyramid;

int main(){
    int n;

    printf("Enter the no.of rows: ");
    scanf("%d",&n);

    for(int i=1;i<=n;i++){

        for(int j=1;j<=n-i;j++){
            printf(" ");
        }
        for(int k=1;k<=i;k++){
            printf("*");
        }

        printf("\n");
    }

    return 0;
}