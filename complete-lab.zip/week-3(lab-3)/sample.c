#include <stdio.h>
#include <stdbool.h>

int main(){

    char str[] = "madam";
    int length = 0;
    int start = 0;
    int end = 0;

    bool isPalindrome = false;

    for(int i=0;str[i]!='\0';i++){
        length++;
    }

    end = length-1;

    while(start<=end){

        if(str[start]!=str[end]){
            isPalindrome = false;
            break;
        }
        start++;
        end--;
    }

    if(isPalindrome){
        printf("It's a palindrome");
    }else{
        printf("It's not a palindrome");
    }

    return 0;
}